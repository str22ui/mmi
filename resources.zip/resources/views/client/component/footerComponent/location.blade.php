<div class="text-white lg:justify-self-center">
    <h1 class="text-lg border-b-4 border-white  font-bold w-fit">LOKASI</h1>
    <div class="h-32 w-32 mt-5">
        <iframe class="h-32 w-52 md:h-32 md:w-60" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.0223338091296!2d106.74240161425288!3d-6.391119595375549!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69e8b64d6dc8ed%3A0x98664373304e4110!2sYayasan%20Al-Hasra!5e0!3m2!1sid!2sid!4v1680697235567!5m2!1sid!2sid"  style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <p class="font-semibold text-xs mt-3">Alamat</p>
    <p class="text-xs">Jl. Raya Ciputat-Parung Km. 24. <br /> Kec. Bojongsari Baru Kel. Bojongsari Baru Kota Depok <br /> Jawa Barat Indonesia</p>
</div>