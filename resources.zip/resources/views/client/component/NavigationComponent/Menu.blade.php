<a class=" font-bold text-base"  href="/">Home</a>
<a class=" font-bold text-base"  href="/about">About</a>
@include('client.component.NavigationComponent.ProjectDropdown')
{{-- @include('client.component.NavigationComponent.ProfileDropdown') --}}
<a class=" font-bold text-base" href="/contact">Contact</a>

