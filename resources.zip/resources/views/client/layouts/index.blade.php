@include('client.layouts.partials.header')

<body class="overflow-x-hidden">
    @include('client.layouts.partials.nav')

    @yield('content')

</body>

@include('client.layouts.partials.footer')

