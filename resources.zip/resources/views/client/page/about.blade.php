@extends('client.layouts.index')

@section('title', 'About')

@section('content')
    
@endsection