@extends('admin.layouts.index', ['title' => 'Tambah Data Agent', 'page_heading' => 'Tambah Data Agent'])

@section('content')
<section class="row">
	<div class="col card px-3 py-3">

	<div class="my-3 p-3 rounded">

		<!-- Table untuk memanggil data dari database -->
        @include('sweetalert::alert')
		<form method="post" action="{{ route('admin.storeAgent') }}" enctype="multipart/form-data">
        @csrf
            {{-- Title --}}


            <div class="mb-3">
              <input type="hidden" value="0" name="views">
              <label for="nama" class="form-label">Nama Agent</label>
              <input type="text" autofocus value="" name="nama" id="nama" placeholder="Masukkan Nama Agent" class="form-control">
            </div>

            <div class="mb-3">
                <label for="tipe" class="form-label">Tipe Agent</label>
                <select id="tipe" name="tipe"
                    class="form-select bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <option value="Korporat">Korporat</option>
                    <option value="Perorangan">Perorangan</option>

                </select>
            </div>

            <div class="mb-3">
                <input type="hidden" value="0" name="views">
                <label for="kantor" class="form-label">Kantor Agent</label>
                <input type="text" autofocus value="" name="kantor" id="kantor" placeholder="Masukkan Nama Kantor" class="form-control">
              </div>

              <div class="mb-3">
                <input type="hidden" value="0" name="views">
                <label for="no_hp" class="form-label">No Telepon</label>
                <input type="text" autofocus value="" name="no_hp" id="no_hp" placeholder="Masukkan Nomor Telepon" class="form-control">
              </div>

              <div class="mb-3">
                <input type="hidden" value="0" name="views">
                <label for="alamat" class="form-label">Alamat</label>
                <input type="text" autofocus value="" name="alamat" id="alamat" placeholder="Masukkan Alamat" class="form-control">
              </div>

            <button type="submit" class="btn btn-primary">Create</button>
            <a class="btn btn-danger" href="{{ route('admin.perumahan') }}">Back</a>
        </form>

		{{-- Menampilkan total pemasukan --}}
		<div class="d-flex align-items-end flex-column p-2 mb-2">
			{{-- <p class="h4 p-3 rounded fw-bolder">Total Pemasukan : Rp. {{ $totalPemasukan }}</p> --}}
		</div>

  </div>
</div>

</section>

<script>
document.getElementById('tipe').addEventListener('change', function() {
            var kantorInput = document.getElementById('kantor');
            if (this.value === 'Perorangan') {
                kantorInput.value = 'N/A';
                kantorInput.readOnly = true;
            } else {
                kantorInput.value = '';
                kantorInput.readOnly = false;
            }
        });
</script>


@endsection



